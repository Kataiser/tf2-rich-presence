"""A helper module containing the Constants used in the wrapper."""
API_OPTIONS = {'TREND': 'trends',
               'PASTE': 'paste',
               'USER_PASTE': 'list',
               'DELETE_PASTE': 'delete',
               'USER_RAW_PASTE': 'show_paste'}
